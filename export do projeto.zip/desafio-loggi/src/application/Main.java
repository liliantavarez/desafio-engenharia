package application;

import uteis.Armazena;
import uteis.Menu;

public class Main {

	public static void main(String[] args) {

		Armazena.armazenar("288355555123888");
		Armazena.armazenar("335333555584333");
		Armazena.armazenar("223343555124001");
		Armazena.armazenar("002111555874555");
		Armazena.armazenar("111188555654777");
		Armazena.armazenar("111333555123333");
		Armazena.armazenar("432055555123888");
		Armazena.armazenar("079333555584333");
		Armazena.armazenar("155333555124001");
		Armazena.armazenar("333188555584333");
		Armazena.armazenar("555288555123001");
		Armazena.armazenar("111388555123555");
		Armazena.armazenar("066311555874001");
		Armazena.armazenar("110333555123555");
		Armazena.armazenar("333488555584333");
		Armazena.armazenar("455448555123001");
		Armazena.armazenar("022388555123555");
		Armazena.armazenar("432044555845333");
		Armazena.armazenar("034311555874001");
		Armazena.armazenar("288000555367333");

		Menu inicar = new Menu();
		inicar.menu();

	}

}
